
package p1;

import dto.Employee;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

    private static SessionFactory sf;
    static{
     AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties prop=new Properties();
        prop.put("hibernate.dialect","org.hibernate.dialect.MySQLDialect");
        prop.put("hibernate.connection.driver_class","com.mysql.jdbc.Driver");
        prop.put("hibernate.connection.url","jdbc:mysql://localhost:3306/cdac31?zeroDateTimeBehavior=convertToNull");
        prop.put("hibernate.connection.username","cdac31");
        prop.put("hibernate.connection.password","cdac31");
        prop.put("hibernate.hbm2ddl.auto","update");
         prop.put("hibernate.show_sql","true");
         
         cfg.addProperties(prop);
         cfg.addAnnotatedClass(Employee.class);
         sf=cfg.buildSessionFactory();
         
    }
    public static void main(String[] args) {
        boolean flag=true;
        Scanner sc=new Scanner(System.in);
        do
        {
            
            System.out.println("0 to exit");
            System.out.println("1 to select");
            System.out.println("2 to delete");
            System.out.println("3 to select all");
            System.out.println("4 to select by ID");
            
           byte b=sc.nextByte();
           
           switch(b)
       {
               case 0:
                   System.exit(0);
                   break;
               case 1:
                   select();
                   break;
               case 2:
                   delete();
                   break;
               case 3:
                   selectAll();
                   break;
               case 4:
                   SelectWhere();
                   break;
               default:
                   System.out.println("you enter wrong choice");
       }
        }while (flag);
        
       sf.close();;
     
    }
    
    
    private static void select()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where netSalary Between ? and ?");
        q.setFloat(0,80f );
        q.setFloat(1,8000f );
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void SelectWhere()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where Dept=?");
        q.setString(0,"CS");
        List<Employee> l=q.list();
        for (Employee e : l)
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
      private static void delete()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        // Employee s1=new Employee( s.getStudId());
       // s.delete(s1);
        Query q=s.createQuery("delete from Employee where Dept=?");
        q.setString(0,"It");
        int i=q.executeUpdate();
//        s.delete(q);
        t.commit();
        s.close();
    }      

    private static void selectAll()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee");
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
}
