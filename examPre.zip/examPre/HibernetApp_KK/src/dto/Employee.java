package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp2")
public class Employee {
    @Id
    @GeneratedValue
    @Column(name = "emp_Id")
    private int empId;
    @Column(name = "emp_Name",length = 20)
    private String empName;
    @Column(name = "dept",length = 10)
    private String Dept;
    @Column(name = "basic_Sal")
    private Float basicSalary;
    @Column(name = "net_Sal")
    private Float netSalary;

    public Employee() {
    }

    public Employee(int empId) {
        this.empId = empId;
    }

    public Employee(int empId, String empName, String Dept, Float basicSalary, Float netSalary) {
        this.empId = empId;
        this.empName = empName;
        this.Dept = Dept;
        this.basicSalary = basicSalary;
        this.netSalary = netSalary;
    }

    public Employee(String empName, String Dept, Float basicSalary, Float netSalary) {
        this.empName = empName;
        this.Dept = Dept;
        this.basicSalary = basicSalary;
        this.netSalary = netSalary;
    }
    

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDept() {
        return Dept;
    }

    public void setDept(String Dept) {
        this.Dept = Dept;
    }

    public Float getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(Float basicSalary) {
        this.basicSalary = basicSalary;
    }

    public Float getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(Float netSalary) {
        this.netSalary = netSalary;
    }

    @Override
    public String toString() {
        return "Employee{" + "empId=" + empId + ", empName=" + empName + ", Dept=" + Dept + ", basicSalary=" + basicSalary + ", netSalary=" + netSalary + '}';
    }
 
    public void calNetSal()
    {
        netSalary=basicSalary;
    }
}
