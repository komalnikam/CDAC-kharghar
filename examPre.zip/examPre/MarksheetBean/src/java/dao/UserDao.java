
package dao;


import conn.MyConnection;
import dto.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao {
    
    private Connection conn;
    
    public UserDao()
    {
            conn=new MyConnection().getMyConnection();
    }
    
    public boolean login(User user)
    {
       boolean flag=false;
       try
       {
           PreparedStatement s=conn.prepareStatement("select * from stud_Details where userName=? and userPass=? and userRole=?");
           s.setString(1,user.getUserName());
           s.setString(2,user.getUserPass());
           s.setString(3,user.getUserRole());
           ResultSet rs=s.executeQuery();
           while(rs.next())
           {
               flag=true;
           }
           conn.close();
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
        return flag;
    }
    
    public ArrayList<User> allUser()
    {
      ArrayList<User> l=new ArrayList<User>();
      try{
            PreparedStatement s=conn.prepareStatement("select userRoll,userName,marks,dob from stud_Details");
            ResultSet rs=s.executeQuery();
            while(rs.next())
            {

               User u=new User();
                u.setUserRoll(rs.getInt(1));
                u.setUserName(rs.getString(2));
                u.setMarks(rs.getFloat(3));
                u.setDob(rs.getString(4));
                l.add(u);
            }
      conn.close();
      
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return l;
    }
    
    public void createUser(User user)
    {
        try {
              PreparedStatement s=conn.prepareStatement("insert into stud_Details (userName,userPass,userRole,marks,dob) values(?,?,?,?,?)");
               s.setString(1,user.getUserName());
               s.setString(2,user.getUserPass());
               s.setString(3,user.getUserRole());
               s.setFloat(4,user.getMarks());
               s.setString(5,user.getDob());
               
               int i=s.executeUpdate();
               conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void removeUser(User user)
    {
        try
        {
            PreparedStatement s=conn.prepareStatement("delete from stud_Details where userRoll= ?");
            s.setInt(1,user.getUserRoll());
            int i=s.executeUpdate();
            conn.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
    }
    
    public User selectUser(User user)
    {
        try
        {
           PreparedStatement s=conn.prepareStatement("select userRoll,userName,marks,dob from stud_Details where userRoll= ?");
            s.setInt(1,user.getUserRoll());
            ResultSet rs  = s.executeQuery();
            if(rs.next())
                    {
                      user.setUserRoll(rs.getInt(1));
                      user.setUserName(rs.getString(2));
                      user.setMarks(rs.getFloat(3));
                      user.setDob(rs.getString(4));

                        conn.close();
                    }
        }
       catch(SQLException e)
        {
            e.printStackTrace();
        }       
        return user;
    }
     public void updateUser(User user)
    {
        try
        {
            PreparedStatement s=conn.prepareStatement("update stud_Details set userName= ?,marks= ?,dob= ? where userRoll= ?");
            s.setString(1,user.getUserName());
            s.setFloat(2,user.getMarks());
            s.setString(3,user.getDob());
            s.setInt(4,user.getUserRoll());
             int i = s.executeUpdate();
            conn.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
    }
     
     public void updatePass(User user)
     {
         try{
             PreparedStatement s=conn.prepareStatement("update stud_Details set userPass=? where userName=?");
             s.setString(1,user.getUserPass());
             s.setString(2,user.getUserName());
             s.executeUpdate();
             conn.close();
         }
         catch(SQLException e)
         {
             e.printStackTrace();
         }
               
     }
     
     
         public User UserMarkList(User user)
    {
        try
        {
           PreparedStatement s=conn.prepareStatement("select userRoll,userName,marks,dob from stud_Details where userName= ?");
            s.setString(1,user.getUserName());
            ResultSet rs  = s.executeQuery();
            if(rs.next())
                    {
                      user.setUserRoll(rs.getInt(1));
                      user.setUserName(rs.getString(2));
                      user.setMarks(rs.getFloat(3));
                      user.setDob(rs.getString(4));

                        conn.close();
                    }
        }
       catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        return user;
    }
}
