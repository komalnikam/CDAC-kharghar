
package dto;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table (name ="stud_details1")
public class Student 
{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int studId;
    private String studName;
    @Temporal(TemporalType.DATE)
    private Date dob;
    private String course;
    private float fee;

    public Student() {
    }

    public Student(int studId) {
        this.studId = studId;
    }

    public Student(String studName, Date dob, String course, float fee) {
        this.studName = studName;
        this.dob = dob;
        this.course = course;
        this.fee = fee;
    }
    
    

    public Student(int studId, String studName, Date dob, String course, float fee) {
        this.studId = studId;
        this.studName = studName;
        this.dob = dob;
        this.course = course;
        this.fee = fee;
    }

    public int getStudId() {
        return studId;
    }

    public void setStudId(int studId) {
        this.studId = studId;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public float getFee() {
        return fee;
    }

    public void setFee(float fee) {
        this.fee = fee;
    }

    @Override
    public String toString() {
        return "Student{" + "studId=" + studId + ", studName=" + studName + ", dob=" + dob + ", course=" + course + ", fee=" + fee + '}';
    }
    
    
}
