package p1;

import dto.Student;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

    private static SessionFactory sf;

    public Main() {
    }
    
     public SessionFactory MyCon()
    {
      if(sf==null || sf.isClosed())
      {
        
     AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties prop=new Properties();
        prop.put("hibernate.dialect","org.hibernate.dialect.MySQLDialect");
        prop.put("hibernate.connection.driver_class","com.mysql.jdbc.Driver");
        prop.put("hibernate.connection.url","jdbc:mysql://localhost:3306/cdac31");
        prop.put("hibernate.connection.username","cdac31");
        prop.put("hibernate.connection.password","cdac31");
        prop.put("hibernate.hbm2ddl.auto","update");
         prop.put("hibernate.show_sql","true");
         cfg.addProperties(prop);
         cfg.addAnnotatedClass(Student.class);
         sf=cfg.buildSessionFactory();
         
    }
      return sf;
}
}
    