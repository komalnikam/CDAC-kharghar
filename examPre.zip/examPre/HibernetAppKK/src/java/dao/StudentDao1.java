
package dao;

import dto.Student;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import p1.Main;

public class StudentDao1 {
    private static SessionFactory sf;

    public StudentDao1() {
        
        sf=new Main().MyCon();
    }
    
    
    public static void insert(Student s)
    {
        Session s1=sf.openSession();
        Transaction t=s1.beginTransaction();
        s1.save(s);
        t.commit();
        s1.close();
    }
    
    
     public static void delete(Student s)
    {
        Session s1=sf.openSession();
        Transaction t=s1.beginTransaction();
        Student s2=new Student(s.getStudId());
        s1.delete(s2);
        t.commit();
        s1.close();
        
    }
    
     public static void update(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("update Student set dob=?,course=?,fee=? where studName=?");
        q.setDate(0,std.getDob());
        q.setString(1,std.getCourse());
        q.setFloat(2,std.getFee());
        q.setString(3,std.getStudName());
        q.executeUpdate();
          t.commit();
         s.close();
        
    }
     
//     public static List<Student> select (Student std)
//    {
//          Session s=sf.openSession();
//        Transaction t=s.beginTransaction();       
//        Query q=s.createQuery("from Student where StudId=?");
//        q.setParameter(0,std.getStudId());
//         List<Student> l=q.list();
//        return l;
//        
//    }  
      public static Student select (Student std)
    {
        System.out.println(std);
          Session s=sf.openSession();
        Transaction t=s.beginTransaction();       
        Query q=s.createQuery("from Student where StudId=?");
        q.setParameter(0,std.getStudId());
         Student l=(Student) q.uniqueResult();
           t.commit();
         s.close();
        return l;
        
    } 
     
     public static List<Student> selectAll()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Student");
         List<Student> l=q.list();
         t.commit();
         s.close();
        return l;
    }
}
