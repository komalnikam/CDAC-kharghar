
package dto;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "Std5")
public class Student {
    
    @Id
    @GeneratedValue
    private int StudId;
    private String studName;
    @Temporal(TemporalType.DATE)
    private Date dob;
    private String course;
    private float fee;

    public Student() {
    }

    public Student(int StudId, String studName, Date dob, String course, float fee) {
        this.StudId = StudId;
        this.studName = studName;
        this.dob = dob;
        this.course = course;
        this.fee = fee;
    }

    public Student(int StudId) {
        this.StudId = StudId;
    }

    public Student(String studName, Date dob, String course, float fee) {
        this.studName = studName;
        this.dob = dob;
        this.course = course;
        this.fee = fee;
    }

    public int getStudId() {
        return StudId;
    }

    public void setStudId(int StudId) {
        this.StudId = StudId;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String StudName) {
        this.studName = StudName;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public float getFee() {
        return fee;
    }

    public void setFee(float fee) {
        this.fee = fee;
    }

    @Override
    public String toString() {
        return StudId + "" + studName + "" + dob + "" + course + "" + fee;
    }

   
}
