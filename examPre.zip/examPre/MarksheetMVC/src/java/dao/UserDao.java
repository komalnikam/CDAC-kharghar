
package dao;

import conn.MyConnection;
import dto.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao 
{
    private Connection con;

    public UserDao() 
    {
        con=new MyConnection().getMyConnection();
    }
    
   public boolean login(User u)
   {
       boolean flag=false;
       
       try
       {
           PreparedStatement ps=con.prepareStatement("select * from user3 where userName=? and userPass=? and userRole=?");
           ps.setString(1,u.getUserName());
           ps.setString(2,u.getUserPass());
           ps.setString(3,u.getUserRole());
           
           ResultSet rs=ps.executeQuery();
           while(rs.next())
           {
               flag=true;
           }
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
       
       return flag;
   }
    
    public void Store(User user) throws SQLException
    {
        PreparedStatement s=con.prepareStatement("insert into user3 values(?,?,?,?,?,?)");
            s.setInt(1,user.getUserRoll());
            s.setString(2,user.getUserName());
            s.setString(3,user.getUserPass());
            s.setString(4,user.getUserRole());
            s.setFloat(5,user.getMarks());
            s.setString(6,user.getDob());
          
            int i=s.executeUpdate();
            con.close();
    }
    
   public ArrayList<User> allUser() throws SQLException
   {
       ArrayList<User> l=new ArrayList<>();
        PreparedStatement s=con.prepareStatement("select userRoll,userName,marks,dob from user3");
        ResultSet rs=s.executeQuery();
        while(rs.next())
        {
              User u=new User();
                u.setUserRoll(rs.getInt(1));
                u.setUserName(rs.getString(2));
                u.setMarks(rs.getFloat(3));
                u.setDob(rs.getString(4));
                l.add(u);
        }
       return l;
   }
    
   public User selectUser(User u) throws SQLException
   {
       PreparedStatement s=con.prepareStatement("select userRoll,userName,marks,dob from user3 where userRoll=?");
       s.setInt(1,u.getUserRoll());
       ResultSet rs=s.executeQuery();
       while(rs.next())
       {
           u.setUserRoll(rs.getInt(1));
           u.setUserName(rs.getString(2));
           u.setMarks(rs.getFloat(3));
           u.setDob(rs.getString(4));
       }
       return u;
   }
   
   public void updateUser(User u) throws SQLException
   {
        PreparedStatement s=con.prepareStatement("update user3 set userName= ?,marks= ?,dob= ? where userRoll=?");
        s.setString(1,u.getUserName());
        s.setFloat(2,u.getMarks());
        s.setString(3,u.getDob());
        s.setInt(4,u.getUserRoll());
        s.executeUpdate();
        con.close();
   }
    
}
