﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsExample
{
    class Program
    {
        static void Main1(string[] args)
        {
            IntegerStack o = new IntegerStack(3);
            o.Push(10);
            o.Push(20);
            o.Push(30);

            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());

            Console.ReadLine();
        }
        static void Main2(string[] args)
        {
            //IntegerStack o = new IntegerStack(3);
            MyStack<int> o = new MyStack<int>(3);
            o.Push(10);
            o.Push(20);
            o.Push(30);

            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());

            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            //IntegerStack o = new IntegerStack(3);
            MyStack<string> o = new MyStack<string>(3);
            o.Push("10");
            o.Push("20");
            o.Push("30");

            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());
            Console.WriteLine(o.Pop());

            Console.ReadLine();
        }
    }
    class IntegerStack
    {
        int[] arr;
        public IntegerStack(int Size)
        {
            arr = new int[Size];
        }
        int Pos = -1;
        public void Push(int i)
        {
            if (Pos == (arr.Length - 1))
                throw new Exception("Stack full");
            arr[++Pos] = i;
        }
        public int Pop()
        {
            if (Pos == -1)
                throw new Exception("Stack Empty");
            return arr[Pos--];
        }
    }
    class MyStack<T>
        //where T : class
    {
        T[] arr;
        public MyStack(int Size)
        {
            arr = new T[Size];
        }
        int Pos = -1;
        public void Push(T i)
        {
            if (Pos == (arr.Length - 1))
                throw new Exception("Stack full");
            arr[++Pos] = i;
        }
        public T Pop()
        {
            if (Pos == -1)
                throw new Exception("Stack Empty");
            return arr[Pos--];
        }
    }
}
