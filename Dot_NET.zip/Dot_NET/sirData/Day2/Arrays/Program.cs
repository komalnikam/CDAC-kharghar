﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main1()
        {
            int[] arr = new int[5];
            for (int i = 0; i < arr.Length; i++)
            {
                //arr[i] = int.Parse(Console.ReadLine());
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }
            int pos = Array.IndexOf(arr, 30);
            //if(pos ==-1)
            Console.ReadLine();
        }
        static void Main()
        {
            int[,] arr = new int[5,3];
            Console.WriteLine(arr.Length);
            Console.WriteLine(arr.Rank);
            Console.WriteLine(arr.GetUpperBound(0));
            Console.WriteLine(arr.GetUpperBound(1));
            Console.WriteLine(arr.GetLength(0));
            Console.WriteLine(arr.GetLength(1));

            for (int i = 0; i < arr.GetLength(0); i++)
                for (int j = 0; j < arr.GetLength(1); j++)
                     arr[i,j] = Convert.ToInt32(Console.ReadLine());

            foreach (int i in arr)
                Console.WriteLine(i);
            Console.ReadLine();
        }
    }
}
