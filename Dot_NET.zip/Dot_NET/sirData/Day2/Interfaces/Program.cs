﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    class Program
    {
        static void Main1()
        {
            Class1 o = new Class1();
            //method 1
            o.Insert();

            //method 2
            IDbFunctions oIDb;
            oIDb = o;
            oIDb.Insert();

            //method 3
            ((IDbFunctions)o).Insert();


            Console.ReadLine();
        }
    }

    public interface IDbFunctions
    {
        void Insert();
        void Update();
        void Delete();
    }
    public class Class1 : IDbFunctions
    {
        public void Display()
        {
            Console.WriteLine("Display");
        }
        public void Insert()
        {
            Console.WriteLine("Idb.Insert from Class1");
        }

        public void Update()
        {
            Console.WriteLine("Idb.Update from Class1");
        }

        public void Delete()
        {
            Console.WriteLine("Idb.Delete from Class1");
        }
    }


}
namespace Interfaces2
{
    class Program
    {
        static void Main()
        {
            Class1 o = new Class1();
            //o.Delete();

            IFileFunctions oIFile;
            oIFile = o;
            oIFile.Delete();

            IDbFunctions oIDb;
            oIDb = o;
            oIDb.Delete();

            //((IFileFunctions)o).


            Console.ReadLine();
        }
    }

    public interface IDbFunctions
    {
        void Insert();
        void Update();
        void Delete();
    }
    public interface IFileFunctions
    {
        void Open();
        void Close();
        void Delete();
    }
    public class Class1 : IDbFunctions, IFileFunctions
    {
        public void Display()
        {
            Console.WriteLine("Display");
        }
        public void Insert()
        {
            Console.WriteLine("Idb.Insert from Class1");
        }
        public void Update()
        {
            Console.WriteLine("Idb.Update from Class1");
        }
         void IDbFunctions.Delete()
        {
            Console.WriteLine("Idb.Delete from Class1");
        }



        void IFileFunctions.Open()
        {
            throw new NotImplementedException();
        }

        void IFileFunctions.Close()
        {
            throw new NotImplementedException();
        }

        void IFileFunctions.Delete()
        {
            Console.WriteLine("IFile.Delete from Class1");
        }
    }


}