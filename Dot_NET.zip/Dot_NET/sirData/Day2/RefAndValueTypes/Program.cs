﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefAndValueTypes
{
    class Program
    {
        static void Main1()
        {
            Class1 o1 = new Class1();
            Class1 o2 = new Class1();
            o1.i = 100;
            o2.i = 200;
            o1 = o2;
            o2.i = 300;
            Console.WriteLine(o1.i);
            Console.WriteLine(o2.i);
            //300,300
            //200,300
            Console.ReadLine();
        }
        static void Main2()
        {
            int o1;
            int o2;
            o1 = 100;
            o2 = 200;
            o1 = o2;
            o2 = 300;
            Console.WriteLine(o1);
            Console.WriteLine(o2);
            //200,300
            //300,300
            Console.ReadLine();
        }
        static void Main()
        {

            string o1;
            string o2;
            o1 = "100";
            o2 = "200";
            o1 = o2;
            o2 = "300";
            Console.WriteLine(o1);
            Console.WriteLine(o2);
            Console.ReadLine();
        }
        void DataTypes()
        {
            //c# data type       //CTS data type
            bool b; Boolean b2;
            byte by; Byte by2;
            sbyte sby; SByte sby2;
            char c; Char c2;
            short sh; Int16 sh2;
            ushort ush; UInt16 ush2;
            int i; Int32 i2;
            uint uin; UInt32 uin2;
            long l; Int64 l2;
            ulong ul; UInt64 ul2;
            float f; Single f2;
            double d; Double d2;
            decimal dec; Decimal dec2;

            string s; String s2;
            object o; Object o2;
        }
    }

    public class Class1
    {
        public int i;
    }

}
