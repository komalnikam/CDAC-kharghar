﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CallByRef
{
    class Program
    {
        static void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        static void Init(out int a, out int b)
        {
            //Console.WriteLine(a); //wont work
            a = 100;
            b = 200;
            //out variables must be initialised in the function before the func ends
        }
        static void Main1()
        {
            //int a = 1, b = 2;
            int a , b ;
            //out variables dont need to be initialised before use
            //even if they have an initial value, that value is lost
            Init(out a, out b);
            Swap(ref a, ref b);
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.ReadLine();

        }


        static void Main()
        {
            Class1 o1 = new Class1();
            o1.i = 100;
            //Func1(o1);
            //Func2(o1);
            Func3(ref o1);
            Console.WriteLine(o1.i);
            Console.ReadLine();
        }
        static void Func1(Class1 o1)
        {
            o1.i++;
        }
        static void Func2(Class1 o1)
        {
            o1 = new Class1();
            o1.i++;
        }
        //pass a reference type as 'ref' to allow original reference to point to a new location
        static void Func3(ref Class1 o1)
        {
            o1 = new Class1();
            o1.i++;
        }

    }
    class Class1
    {
        public int i;
    }
}
