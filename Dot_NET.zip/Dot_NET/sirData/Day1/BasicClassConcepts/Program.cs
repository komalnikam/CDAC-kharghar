﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BasicClassConcepts
{
    class Program
    {
        //trying functions
        static void Main1()
        {

            //System.Data.DataSet ds1;
            //DataSet ds2;
            //System.Console.WriteLine("Hello World");
            //Console.WriteLine("Hello World");

            Class1 o = new Class1();
            o.Display();
            o.Display("a");

            Console.WriteLine(o.Sum(10, 20, 30, 40));
            Console.WriteLine(o.Sum(10, 20, 30));
            Console.WriteLine(o.Sum(10, 20));


            o.FuncWithParams(1, 2, 3, 4, 5);
            //o.FuncWithParams(1, 2, 3, 4);
            //o.FuncWithParams(1, 2, 3);
            //o.FuncWithParams(1, 2);

            Console.ReadLine();
        }


        //trying properties
        static void Main2()
        {

            Class1 o = new Class1();
            //o.i = 100;
            //Console.WriteLine(o.i);

            o.P1 = 40;
            Console.WriteLine(o.P1);

            //o.P2 = 12;

            //o.P3 = 12;
            o.P4 = 100;
            Console.WriteLine(o.P4);
            Console.ReadLine();
        }
    
        static void Main3()
        {
            Class1 o1 = new Class1();
            Console.WriteLine(o1.P1);

            Class1 o2 = new Class1(10, 20);
            Console.WriteLine(o2.P1);

            o1 = null;
            o2 = null;
            Console.ReadLine();
        }

        static void Main()
        {
            Class1 o = new Class1();
            //positional parameters
            //o.DoSomething(10, 20, 30, 40);
            //named parameters
            //o.DoSomething(a: 10, d: 40, c: 30, b: 20);
            //name params with optional params
            o.DoSomething2(d: 40);
            Console.ReadLine();
        }
    }

    public class Class1
    {
        #region functions
        public void DoSomething(int a, int b, int c, int d)
        {
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
        }
        public void DoSomething2(int a = 0, int b=0, int c=0, int d=0)
        {
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
        }

        public void Display()
        {
            Console.WriteLine("Disp");
        }
        //method overloading
        public void Display(string s)
        {
            Console.WriteLine("Disp" + s);
        }

        //optional parameters
        //start optional params from the right
        public int Sum(int a, int b, int c = 0, int d = 0)
        {
            return a + b + c + d;
        }


        //params
        public void FuncWithParams(params int[] p)
        {
            Console.WriteLine(p.Length);
            for (int i = 0; i < p.Length; i++)
            {
                Console.WriteLine(p[i]);
            }

        }
        #endregion

        #region properties
        //variable
        public int i;

        //property
        private int p1;
        public int P1
        {
            get
            {
                return p1;
            }
            set
            {
                if (value < 50)
                    p1 = value;
                //value is a keyword that contains the value being passed 
                //to the property
                else
                    Console.WriteLine("invalid value");
            }
        }
        //readonly property
        private int p2;
        public int P2
        {
            get
            {
                return p2;
            }
        }

        //property
        //read only using a property accessor
        //only one out of get/set can have a property accessor
        //you can decrease access, not increase it
        private int p3;
        public int P3
        {
             get
            {
                return p3;
            }
            private set  // property accessor
            {
                    p3 = value;
            }
        }

        //automatic properties
        //compiler generates code for get and set
        //compiler generates a private variable
        //use auto prop when there are no validations
        public int P4 { get; set; }
        #endregion


        #region constructor
        public Class1()
        {
            Console.WriteLine("const");
        }
        public Class1(int P1, int P3)
        {
            Console.WriteLine("const with initial values being received");
            this.P1 = P1;
            this.P3 = P3;
        }
        #endregion


        //please do not use this in real world apps
        ~Class1()
        {
            Console.WriteLine("destructor. but NEVER use it in dotnet");

        }
    }
}
