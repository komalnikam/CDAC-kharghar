﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class SuperClass
    {
        public SuperClass()
        {
            Console.WriteLine("SuperClass Const");
        }

        public void Display11()
        {
            Console.WriteLine("Display11 of Superclass");
        }
        public void Display22()
        {
            Console.WriteLine("Display22 of Superclass");
        }
        public void Display33()
        {
            Console.WriteLine("Display33 of Superclass");
        }
    }
    public class SubClass:SuperClass
    {
        public SubClass()
        {
            Console.WriteLine("SubClass Const");
        }

        public new void Display11()
        {
            Console.WriteLine(" SubClass Display11");
        }
        public new void Display22()
        {
            Console.WriteLine("SubClass Display22");
        }
        public new void Display33()
        {
            Console.WriteLine("SubClass Display33");
        }
    }
    public class SubSubClass : SubClass
    {
        public SubSubClass()
        {
            Console.WriteLine("SubSubClass Const");
        }

        public new void Display11()
        {
            Console.WriteLine(" SubSubClass Display11");
        }
        public new void Display22()
        {
            Console.WriteLine("SubSubClass Display22");
        }
        public new void Display33()
        {
            Console.WriteLine("SubSubClass Display33");
        }
    }

    class FunctionOverriding
    {
        static void Main3()
        {
            SubClass s = new SubClass();
            s.Display11();
            s.Display22();
            s.Display33();

            SuperClass ss = new SuperClass();
            ss.Display11();
            ss.Display22();
            ss.Display33();

            SubSubClass sss = new SubSubClass();
            sss.Display11();
            sss.Display22();
            sss.Display33();

        }
    } 


}
