﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    class Program
    {
        static void Main1()
        {
            int[] arr = new int[5];
            for(int i=0;i<arr.Length;i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            foreach(int i in arr)
            {
                Console.WriteLine("values-->>"+i);
            }
            Console.ReadLine();
        }

        static void Main()
        {
            int[,] arr = new int[5,3];
            Console.WriteLine("Lenght-->>"+arr.Length);
            Console.WriteLine("Rank-->>" + arr.Rank);
            Console.WriteLine("Lenght-->>" + arr.GetUpperBound(0));
            Console.WriteLine("Lenght-->>" + arr.GetUpperBound(1));
            Console.WriteLine("Lenght-->>" + arr.GetLength(1));

            for(int i=0;i<arr.GetLength(0);i++)
            {
                for(int j=0;j<arr.GetLength(1);j++)
                {
                    arr[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }
    }
}
