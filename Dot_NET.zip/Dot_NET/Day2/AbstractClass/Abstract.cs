﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    public abstract class  Base
    {
        public int i;
        public abstract void Display();
    }


    public class Derived : Base
    {

        public override void Display()
        {
            Console.WriteLine("Display method in Derived");
        }
    }
    class Abstract
    {
        static void Main1(string[] args)
        {

            Derived d = new Derived();
            d.Display();
        }
    }
}
