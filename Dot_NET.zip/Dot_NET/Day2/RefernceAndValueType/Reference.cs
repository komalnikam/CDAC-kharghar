﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefernceAndValueType
{
    public class Sample
    {
        public int i;
          

    }

    class Reference
    {
        static void Main1(string[] args)
        {
            Sample s = new Sample();
            s.i = 100;
            Sample s1 = new Sample();
            s1.i = 200;
            s = s1;
            s1.i = 300;
            Console.WriteLine("s.i -->>"+s.i);
            Console.WriteLine("s1.i -->>"+s1.i);
        }


        static void Main2()
        {
            int i1=100;
            int i2=200;

            i1 = i2;
            i2 = 300;
            Console.WriteLine("i1"+i1);
            Console.WriteLine("i2"+i2);
        }

        static void Main()
        {
            string s1;
            string s2;
            s1 = "Komal";
            s2 = "Nikam";
            s1 = s2;
            s2 = "Shirke";
            Console.WriteLine("s1-->>"+s1);
            Console.WriteLine("s2 -->>"+s2);
        }
    }
}
