﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefernceAndOut
{
    class RefOut
    {

        static void swap( ref int a, ref int b)
        {
            int temp;
            temp = a;
            a = b;
            b = temp;
        }
        static void Komal(out int a, out int b)
        {
            a = 100;
            b = 300;
        }
        static void Main1(string[] args)
        {
            int a;
            int b;

           // int a = 100;
           // int b = 200;
            Komal(out  a, out b);
            swap( ref a,ref b);
            //swap(ref  a,ref  b);
            Console.WriteLine("After Swap A: "+a);
            Console.WriteLine("After Swap B: "+b);

        }
    }
}
