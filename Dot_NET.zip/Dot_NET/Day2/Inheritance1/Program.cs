﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance1
{


    public class BaseAssembly
    {
        public int PUBLIC;
        private String PRIVATE;
        protected float PROTECTED;
        internal double INTERNAL;
        protected internal int PROTECTED_INTERNAL;

        public BaseAssembly()
        {
            Console.WriteLine("Constructor of Base Inheritance1");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
