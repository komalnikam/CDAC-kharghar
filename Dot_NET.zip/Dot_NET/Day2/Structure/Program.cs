﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    class Program
    {
        public struct Books
        {
            public String a;
            public String b;
            public String c;
            public String d;
        }
        static void Main(string[] args)
        {
            Books b;
            b = new Books();
            b.a = "AJAVA";
            b.b = "C++";
            b.c = "DS";
            b.d = "DotNet";

            Console.WriteLine("Book1-->>"+b.a);
            Console.WriteLine("Book2-->>"+b.b);
            Console.WriteLine("Book3-->>"+b.c);
            Console.WriteLine("Book4-->>"+b.d);
            Console.ReadLine();
        }
    }
}
