﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class Program
    {
        static void Main1(string[] args)
        {
            Class1 c = new Class1();
            c = null;
            int i = int.Parse(Console.ReadLine());
            try
            {
                Console.WriteLine( (100 / i));
                Console.WriteLine(c.a);
            }
            catch
            {
                Console.WriteLine("Ëxception Occure");
            }

            Console.ReadLine();

        }
    }

    public class Class1
    {
        public int a=20;
    }
}

namespace ExceptionHandling1
{
    class Program
    {
        static void Main2(string[] args)
        {
            Class1 c = new Class1();

            try
            {
                int i;
                c = null;
                i = int.Parse(Console.ReadLine());
                c.a = 100 / i;
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("finally");

            }
            Console.ReadLine();

        }
    }

    public class Class1
    {
        public int a = 20;
    }
}

namespace ExceptionHandling2
{
    public class Program
    {
        static void Main()
        {
            Class1 c=new Class1();

            try
            {
                int i=0;
                c=null;
                c.P1=100/i;
            }
            catch(InvalidP1Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }

    public class Class1
    {
        private int p1;

        public int P1
        {
          get 
          { 
              return p1;
          }
          set 
          { 
              if(value<100)
              p1 = value;
              throw new InvalidP1Exception("Enter value Greater than 100");
          }
        }

    }

    public class InvalidP1Exception:ApplicationException
    {
        public InvalidP1Exception(string message): base(message)
        {

        }
    }
}