﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate void Del1();
    public delegate int DelAdd(int a,int b);
    public delegate void DelInfo(string c,int a, float b);

    class Program
    {
        static void Display()
        {
            Console.WriteLine("Display");
        }
        static void Show()
        {
            Console.WriteLine("Show");
        }

        static int Add(int a,int b)
        {
            return a + b;
        }

        static void Info(String a, int b, float c)
        {
            Console.WriteLine("Empname= " + a + "\n" + "EmpId= " + b + "\n" + "EmpSal= " + c);  
        }

        
        static void Main1(string[] args)
        {
            //Del1 p = new Del1(Display);
           // Del1 p = Display;
            //p();
           // p = Show;
           // p();

            Del1 objDel=(Del1)Delegate.Combine(new Del1(Display), new Del1(Show),new Del1(Display));
         objDel();

         Console.WriteLine("----------------------");

            Del1 obj = (Del1)Delegate.Remove(objDel,new Del1(Display));
            obj();

            Console.WriteLine("----------------------");

            Del1 obj1 = (Del1)Delegate.RemoveAll(objDel, new Del1(Display));
            obj1(); 

        }

        static void Main21(string[] args)
        {
            Del1 D = new Del1(Display);
            Del1 D1 = Display;
            D += Show;
            D();

            Console.WriteLine("----------------------");
            D -= Show;
            D();
        }
       
        
        static void Main22(string[] args)
        {
            DelAdd a = Add;
            Console.WriteLine( "Addition = "+a(10, 20));

            DelInfo i =Info;
            i("Komal", 12, 12.32f);
        }
    }
}
