﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Predicate
    {
        static void  Main()
        {
            Predicate<int> obj = new Predicate<int>(isEven);
            bool b=obj(10);
            if(b)
                Console.WriteLine("Even");
            else
                Console.WriteLine("Odd");

        }
        static bool isEven(int b)
        {
            return (b % 2 == 0);
        }

    }
    
}

