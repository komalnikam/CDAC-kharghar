﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventHandling
{
    class Program
    {
        static void Main1(string[] args)
        {
            Class1 c = new Class1();
            //p1ChangedEventHandler obj = new p1ChangedEventHandler(o_p1Changed);
            //c.p1Changed+=obj;
            //c.p1=100;

            //c.p1Changed += new p1ChangedEventHandler(o_p1Changed);
            //c.P1 = 200;

            c.p1Changed += o_p1Changed;
            c.P1 = 300;

            Console.ReadLine();
        }
        static void o_p1Changed()
        {
            Console.WriteLine("Event occure");
        }
    }

    public delegate void p1ChangedEventHandler();
    public class Class1
    {
        public event p1ChangedEventHandler p1Changed;
        private int p1;

        public int P1
        {
            get 
            {
                return p1; 
            }
            set 
            { 
                p1 = value;
                p1Changed();
            }
        }
      
    }
}

namespace EventHandling1
{
    class Program
    {
        static void Main2(string[] args)
        {
            Class2 c = new Class2();
            c.p1Changed += c_p1Changed;
            c.P1 = 400;

            Console.ReadLine();
        }

        static void c_p1Changed()
        {
            Console.WriteLine("EVent occured");
        }
      
    }

    public delegate void p1ChangedEventHandler();
    public class Class2
    {
        public event p1ChangedEventHandler p1Changed;
        private int p1;

        public int P1
        {
            get
            {
                return p1;
            }
            set
            {
                p1 = value;
                p1Changed();
            }
        }

    }
}

namespace EventHandling2
{
    class Program
    {
        static void Main4(string[] args)
        {
            Class3 c = new Class3();
            c.p1Changed += c_p1Changed;
            c.p1Changed += Show;
            c.p2Changed += c_p1Changed;
            c.P1 = 500;
            Console.WriteLine(c.P1);
            c.p1Changed -= Show;
            c.P1 = 300;
            Console.WriteLine(c.P1);
            Console.ReadLine();
        }

        static void c_p1Changed()
        {
            Console.WriteLine("EVent occured");
        }

        static void Show()
        {
            Console.WriteLine("Show mwthod called");
        }

    }

    public delegate void p1ChangedEventHandler();
    public class Class3
    {
        public event p1ChangedEventHandler p1Changed;
        public event p1ChangedEventHandler p2Changed;

        private int p1;

        public int P1
        {
            get
            {
                return p1;
            }
            set
            {
                p1 = value;
                p1Changed();
                p2Changed();
            }
        }

    }
}

namespace EventHandling3
{
    class Program
    {
        static void Main3(string[] args)
        {
            Class4 c = new Class4();
            //c.p1Changed += c_p1Changed;
            //c.p1Changed += Show;
            c.P1 = 500;
            Console.WriteLine(c.P1);
            Console.ReadLine();
        }

        static void c_p1Changed()
        {
            Console.WriteLine("EVent occured");
        }

        static void Show()
        {
            Console.WriteLine("Show mwthod called");
        }

    }

    public delegate void p1ChangedEventHandler();
    public class Class4
    {
        public event p1ChangedEventHandler p1Changed;
        private int p1;

        public int P1
        {
            get
            {
                return p1;
            }
            set
            {
                p1 = value;
                if(p1Changed!=null)
                p1Changed();
            }
        }

    }
}