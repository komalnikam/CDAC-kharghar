
package p1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "CounterServlet", urlPatterns = {"/CounterServlet"})
public class CounterServlet extends HttpServlet {
//public int i;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
           // Integer count=0;
            
           /*int cout=0;
            int c;
            HttpSession session;
            
            if(request.getSession(false)==null)
            {
            session=request.getSession(true);
            session.setAttribute("Count",cout);
            
            c=(Integer)session.getAttribute("Count");
            
            //out.println(c);
            out.println("Hello visiting 1st time");
                    c=2;
                    session=request.getSession(false);
                    session.setAttribute("Count",c);
            }
            else
            {
                session=request.getSession(false);
                int count=(Integer)session.getAttribute("Count");
                out.println(count);
                if(count!=0)
                {
                   if(count<10)
                    {
                        out.println("visiting count: "+ count);
                        count++;
                        session.setAttribute("Count",count);
                    }
                    else
                    {
                        session.setAttribute("Count",1);
                        out.println("visiting count: "+ count);
                    }

                }
            }
        
            int count=0;
            
            HttpSession session=request.getSession();
            boolean b=session.isNew();
            
            if(b)
            {
                if(count<10)
                {
                count++;
                }
                else
                {
                    count=0;
                }
            }
            else
            {
                if(count<10)
                {
                count ++;
                }
                        
            }*/
            String title = "Welcome Back to my website";
            HttpSession session = request.getSession(true);
            Integer visitCount = new Integer(0);
            String visitCountKey = new String("visitCount");
            if (session.isNew())
                {
                    title = "Welcome to my website";
                } 
            else {
                    visitCount = (Integer)session.getAttribute(visitCountKey);
                    if(visitCount<10)
                    {
                    visitCount = visitCount + 1;
                    }
                    else
                    {
                        visitCount=0;
                    }
                   }
             session.setAttribute(visitCountKey,  visitCount);
             response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
      
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CounterServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<form action='CounterServlet'>");
         //   out.println("<>");
            out.println("<h1>"+title+"</h1>");
            out.println("<h1>Your Visiting "+ visitCount  +" time</h1>");
            out.println("<input type='submit' value='hits'>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
