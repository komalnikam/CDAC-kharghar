
package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "emp_anno")
@DynamicInsert(true)
@DynamicUpdate(true)

public class Employee {
    @Id
    @Column(name = "emp_id")
    private int empId;
    @Column(name = "emp_name",length = 15)
    private String empName;
    @Column(length = 4)
    private String dept;
    @Column(name = "basic_sal")
    private float basicSal;
    @Column(name = "net_sal")
    private float netSal;

    public Employee() {
    }

    public Employee(int empId, String empName, String dept, float basicSal) {
        this.empId = empId;
        this.empName = empName;
        this.dept = dept;
        this.basicSal = basicSal;
    }
 
    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public float getBasicSal() {
        return basicSal;
    }

    public void setBasicSal(float basicSal) {
        this.basicSal = basicSal;
    }

    public float getNetSal() {
        return netSal;
    }

    public void calNetSal() {
        netSal = basicSal;
    }

    @Override
    public String toString() {
        return "Employee{" + "empId=" + empId + ", empName=" + empName + ", dept=" + dept + ", basicSal=" + basicSal + ", netSal=" + netSal + '}';
    }
    
}
