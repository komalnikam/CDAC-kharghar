
package p1;

import dto.Employee;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main1 {

    public static void main(String[] args) {
        AnnotationConfiguration cfg= new AnnotationConfiguration();
       Properties props=new Properties();
            props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
            props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
            props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
            props.put("hibernate.connection.username", "cdac31");
            props.put("hibernate.connection.password", "cdac31");
            props.put("hibernate.hbm2ddl.auto", "update");
            props.put("hibernate.show_sql", "true");
            cfg.addProperties(props);
            cfg.addAnnotatedClass(Employee.class);
            SessionFactory sf=cfg.buildSessionFactory();
            Session s=sf.openSession();
            Transaction t=s.beginTransaction();
            Employee e = new Employee(20, null, null,0.00f);
            e.calNetSal();
            s.save(e);
            t.commit();
            s.close();
            sf.close();
       
            
    }
    
}
