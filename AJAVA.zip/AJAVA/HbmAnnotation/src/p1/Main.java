
package p1;

import dto.Employee;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {

    public static void main(String[] args) {
        AnnotationConfiguration cfg= new AnnotationConfiguration();
       Properties props=new Properties();
            props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
            props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
            props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
            props.put("hibernate.connection.username", "cdac31");
            props.put("hibernate.connection.password", "cdac31");
            props.put("hibernate.hbm2ddl.auto", "update");
            props.put("hibernate.show_sql", "true");
            cfg.addProperties(props);
            cfg.addAnnotatedClass(Employee.class);
            SessionFactory sf=cfg.buildSessionFactory();
            Session s=sf.openSession();
            Transaction t=s.beginTransaction();
           //Employee e = (Employee)s.get(Employee.class, 1);
              // if(e!= null)
          //System.out.println("get called");
          Employee e = (Employee)s.load(Employee.class, 1);
            System.out.println("load called");
           //System.out.println(e.getEmpId());
           System.out.println(e);
            e.calNetSal();
            s.save(e);
            t.commit();
            s.close();
            sf.close();
       
            
    }
    
}
