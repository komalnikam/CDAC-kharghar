
package p1;

import dto.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class main {

    public static void main(String[] args) {

        Configuration config=new Configuration();
        config=config.configure();
        SessionFactory sf=config.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
//        Employee e=new Employee("manish","CS",8888.55f);
//        Employee e=new Employee("kunal","ME",777.55f);
        // Employee e = new Employee(7);
//        e.calNetSal();
//        s.save(e);
//        s.delete(e);
//        s.update(e);
        
        Employee e=(Employee)s.get(Employee.class, 1);
        System.out.println(e);
       t.commit();
        s.close();
        sf.close();
    }
    
}
