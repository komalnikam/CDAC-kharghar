
package p2;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrepareSt {
     public static void main(String[] args) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac31","cdac31","cdac31");
            
            PreparedStatement s = con.prepareStatement("select * from emp");
            ResultSet rs = s.executeQuery();
            while(rs.next()){
                System.out.println(rs.getInt(1)+" \t "+rs.getString(2)+" \t "+rs.getInt(3)+" \t "+rs.getString(4)); 
            }
              System.out.println("------------------------------------------");
            while(rs.previous()){
                System.out.println(rs.getInt(1)+" \t "+rs.getString(2)+" \t "+rs.getInt(3)+" \t "+rs.getString(4)); 
            }
                boolean b=s.execute();
                System.out.println("+++"+b);
            
            
            con.close();
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
