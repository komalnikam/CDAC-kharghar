
package dto;

public class user {
   
    private int prodId;
    private String prodName;

    public user() {
    }

    public user(int prodId) {
        this.prodId = prodId;
    }

    public user(int prodId, String prodName) {
        this.prodId = prodId;
        this.prodName = prodName;
    }

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    @Override
    public String toString() {
        return "user{" + "prodId=" + prodId + ", prodName=" + prodName + '}';
    }
   
    
}
