package p1;

import dto.Employee;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;

public class Main {
    private static SessionFactory sf;
    static{
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties props=new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
        props.put("hibernate.connection.username", "cdac31");
        props.put("hibernate.connection.password", "cdac31");
        props.put("hibernate.hbm2ddl.auto", "update");
        props.put("hibernate.show_sql", "true");
        
        cfg.addProperties(props);
        cfg.addAnnotatedClass(Employee.class);
        sf=cfg.buildSessionFactory();
    }
    
    
    public static void main(String[] args) {
        
        Scanner sc =new Scanner(System.in);
        boolean flag=true;
        do{
        
            System.out.println("Enter your choice:");
            System.out.println("0 to exit");
            System.out.println("1 to select all");
            System.out.println("2 to select dept record");
        byte ch=sc.nextByte();
        switch(ch)
        {
            case 0:
                System.exit(0);
                break;
            case 1:
                selectAll1();
                break;
            case 2:
                selectDept();
                break;
            default:
                System.out.println("Wrong Choice");
             
        }
        }while(flag);
        sf.close();
    }
    
    private static void selectAll()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Employee e1 = new Employee();
        e1 = (Employee)s.get(Employee.class, 1);
        System.out.println("--"+e1);
//        System.out.println("--"+e1.getDept());
        
        Criteria q=s.createCriteria(Employee.class);
        List<Employee> l=q.list();
                System.out.println("--"+l);
        System.out.println("--"+q);
        for (Employee e : l) {
            System.out.println("hihihi");   
        }
        
        t.commit();
        //s.close();
    }
    private static void selectAll1(){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
  Criteria q = s.createCriteria(Employee.class);
  List<Employee> l = q.list();
  for(Employee e : l){
   System.out.println(e);
  }
  t.commit();
  s.close();
 }

    private static void selectDept(){
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Criteria q=s.createCriteria(Employee.class);
        q.add(Restrictions.eq("dept", "cs"));
        List<Employee> l=q.list();
                System.out.println("--"+l);

        for( Employee e : l) {
            System.out.println(e);}
        t.commit();
//s.close();
 }
}
