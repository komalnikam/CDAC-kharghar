
package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicInsert;

@Entity
@Table(name = "emp2")
@DynamicInsert
public class Employee {
    
 @Id
 @Column(name = "emp_id")
 private int empId;
 @Column(name="emp_Name")
 private String empName;
 @Column(name="emp_dept")
 private String dept;
 @Column(name="basic_Sal")
 private float basicSal;
 @Column(name="net_Sal") 
  protected float netSal;

    public Employee() {
    }

 
 
    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public float getBasicSal() {
        return basicSal;
    }

    public void setBasicSal(float basicSal) {
        this.basicSal = basicSal;
    }

    public float getNetSal() {
        return netSal;
    }

    public void setNetSal(float netSal) {
        this.netSal = netSal;
    }

    @Override
    public String toString() {
        return "Employee{" + "empId=" + empId + ", empName=" + empName + ", dept=" + dept + ", basicSal=" + basicSal + ", netSal=" + netSal + '}';
    }
    
    public void calNetSal()
    {
        netSal=basicSal;
    }
    
    
}
