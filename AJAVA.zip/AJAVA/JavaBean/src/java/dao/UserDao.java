package dao;

import conn.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import dto.User;
import java.sql.ResultSet;
public class UserDao {
    private Connection con;

    public UserDao() {
       
        con=new MyConnection().getMyConn();
       
    }
    public void createUser(User user)
    {
        try            
        {
            PreparedStatement s =con.prepareStatement("insert into user1(uName,uPass,uRole,joinDate) values(?,?,?,?)");
            System.out.println(s);
            s.setString(1,user.getuName());
            s.setString(2,user.getuPass());
            s.setString(3,user.getuRole());
            s.setString(4,user.getJoinDate());
            
            int i=s.executeUpdate();
            con.close();
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }   
    public boolean login(User user)
    {
        try
        {
            PreparedStatement s=con.prepareStatement("select * from user1 where uName=? and uPass=?");
            s.setString(1,user.getName());
            s.setString(2,user.getPass());
            
            ResultSet rs=s.executeQuery();
            if(rs.next())
            {
                return true;
            }
            else
            {
              return false;
            }
            
        }
        
        catch(SQLException e)
        {
            e.printStackTrace();
            return false;
        }
    }
         
       public int selectUser(User user)
    {
        return 1;
    }
       
        public boolean Delete(String s1)
        {
            try{
                PreparedStatement s=con.prepareStatement("delete from user1 where uId= ?");
                s.setString(1, s1);
                if(s.execute())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(SQLException e)
            {
                e.printStackTrace();
                return false;
            }
            
        }
        
    }
            
    
    
    
    
    

