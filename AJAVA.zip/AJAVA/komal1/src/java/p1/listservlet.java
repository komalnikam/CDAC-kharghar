/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 160840320032
 */
@WebServlet(name = "listservlet", urlPatterns = {"/listservlet"})
public class listservlet extends HttpServlet {

     @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac31","cdac31","cdac31");
                PreparedStatement c=conn.prepareStatement("select * from register");
                ResultSet rs = c.executeQuery();
                out.println("<table border=1>");
                while(rs.next())
                {
                    out.println("<tr><td>"+rs.getInt(1)+"</td> <td>"+rs.getString(2)+"</td>"
                            + "<td> "+rs.getString(3)+" </td><td>"+rs.getString(4)+"</td>"
                            + "<td> "+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td></tr>");
      
                }
                out.println("</table>");
                   conn.close();
                
          
        }catch(ClassNotFoundException e)
            {
                e.printStackTrace();
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
         }
        }
    }