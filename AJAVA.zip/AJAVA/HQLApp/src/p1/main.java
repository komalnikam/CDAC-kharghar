
package p1;

import dto.Employee;
import java.util.Properties;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.*;

public class main {
    
    private static SessionFactory sf;
 static{
  AnnotationConfiguration cfg
          = new AnnotationConfiguration();
  Properties props = new Properties();
  props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
  props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
  props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
  props.put("hibernate.connection.username", "cdac31");
  props.put("hibernate.connection.password", "cdac31");
  props.put("hibernate.hbm2ddl.auto", "update");
  props.put("hibernate.show_sql", "true");
  cfg.addProperties(props);
  cfg.addAnnotatedClass(Employee.class);
  sf = cfg.buildSessionFactory();
 }

    public static void main(String[] args) {
        
        boolean flag=true;
        Scanner sc=new Scanner(System.in);
        
        do
        {
            System.out.println("Enter choice");
            System.out.println("0 to exit");
            System.out.println("1 to select all");
            System.out.println("2 to select Where");
            System.out.println("3 to select Between");
            System.out.println("4 to select Pattern");
            System.out.println("5 to select And");
            System.out.println("6 to select names");
            System.out.println("7 to select names and Sal");
            System.out.println("8 to select distinct dept");
            System.out.println("9 to select Sum of Sal");
            System.out.println("10 to select name descending order");
            System.out.println("11 to select name group by netsal");
            System.out.println("12 to select name group by having");
            System.out.println("13 to select name subquery");
            byte b=sc.nextByte();
            switch(b)
            {
                case 0:
                    System.exit(0);
                    break;
                case 1:
                    selectAll();
                    break;
                case 2:
                    selectWhere();
                    break;
                case 3:
                    selectBetween();
                    break;
                case 4:
                    selectPattern();
                    break;
                case 5:
                    selectAnd();
                    break;
                case 6:
                    selectNames();
                    break;
                case 7:
                    selectNameSal();
                    break;
                case 8:
                    selectDistinctDept();
                    break;
                case 9:
                    selectsum();
                    break;
                case 10:
                    selectOrderBy();
                    break; 
                case 11:
                      groupBy();
                    break;
                case 12:
                      selectSalGroupByHaving();
                    break;
                case 13:
                      selectSubQuery();
                    break;
                default :
                    System.out.println("wrong choice");
            }
            
        }while(flag);
       sf.close();
    }
    
    private static void selectAll()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee");
        List<Employee> l = q.list();
        for (Employee e : l) 
        {
            System.out.println(e);   
        }
        t.commit();
        s.close();
    }
    
    private static void selectWhere()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where dept=?");
        q.setString(0,"cs");
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void selectBetween()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where netSal Between ? and ?");
        q.setFloat(0,80f );
        q.setFloat(1,9000f );
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void selectPattern()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where empName like ?");
        q.setString(0,"k%");
        List<Employee> l=q.list();
        for (Employee e : l)
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
            
    private static void selectAnd()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Employee where dept=? and netSal > ?");
        q.setString(0,"cs");
         q.setFloat(1, 800f);
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void selectNames()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("select empName from Employee");
        List<String> l=q.list();
        for (String e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void selectNameSal()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("select empName,netSal from Employee");
        List<Object[]> l=q.list();
        for (Object[] e : l) 
        {
            System.out.println(e[0]+" "+e[1]);
        }
        t.commit();
        s.close();
    }
    
    private static void selectDistinctDept()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("select distinct(dept) from Employee");
        List<String> l=q.list();
        for (String e :l ) {
            System.out.println(e);
            
        }
        t.commit();
        s.close();
    }
    
    private static  void selectsum()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("select sum(netSal) from Employee");
        List<Double> l=q.list();
        for (Double e : l)
        {
            System.out.println(e); 
        }
        t.commit();
        s.close();
                
    }
    
    private static void selectOrderBy()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
      // Query q=s.createQuery(" from Employee order by netSal desc");
        Query q=s.createQuery("from Employee order by empName desc");
        List<Employee> l=q.list();
        for (Employee e : l) 
        {
            System.out.println(e);
        }
        t.commit();
        s.close();
    }
    
    private static void groupBy()
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
       // Query q = s.createQuery("select dept,sum(netSal) from Employee group by dept");
        Query q=s.createQuery("select dept,sum(netSal) from Employee group by dept");
        List<Object[]>l=q.list();
        for (Object e[] : l) {
            System.out.println(e[0]+""+e[1]);
        }
        t.commit();
        s.close();
    }
    
     private static void selectSalGroupByHaving(){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
  Query q = s.createQuery("select dept,sum(netSal) from Employee group by dept having sum(netSal) > 10000");
  List<Object[]> l = q.list();
  for(Object e[] : l){
   System.out.println(e[0]+" "+e[1]);
  }
  t.commit();
  s.close();
 }
 
 private static void selectSubQuery(){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
  Query q = s.createQuery("from Employee where dept = (select dept from Employee where empName = ?)");
  q.setString(0, "komal");
  List<Employee> l = q.list();
  for(Employee e : l){
   System.out.println(e);
  }
  t.commit();
  s.close();
 }
}
