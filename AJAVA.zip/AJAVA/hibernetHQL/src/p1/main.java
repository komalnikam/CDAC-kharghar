
package p1;

import dto.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class main {
    public static void main(String[] args) {
        Configuration config=new Configuration();
        config=config.configure();
        SessionFactory sf=config.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Employee e=new Employee(1,"komal","cs",9999.99f);
        e.calNetSal();
        s.save(e);
        t.commit();
        s.close();
        sf.close();  
    }
    
}

